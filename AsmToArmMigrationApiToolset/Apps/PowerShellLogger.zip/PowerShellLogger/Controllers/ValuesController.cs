﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PowerShellLogger.Controllers
{
    public static class Values
    {
        static List<string> data1 = new List<string>();
        static List<string> data2 = new List<string>();
        static List<string> data3 = new List<string>();
        static List<string> data4 = new List<string>();
        static List<string> data5 = new List<string>();

        public static void Add1(string v1)
        {
            data1.Add(v1);
        }

        public static void Add2(string v1)
        {
            data2.Add(v1);
        }

        public static void Add3(string v1)
        {
            data3.Add(v1);
        }

        public static void Add4(string v1)
        {
            data4.Add(v1);
        }

        public static void Add5(string v1)
        {
            data5.Add(v1);
        }

        public static string[] Get(int id)
        {
            List<string> data = null;
            if (id == 1) data = data1;
            else if (id == 2) data = data2;
            else if (id == 3) data = data3;
            else if (id == 4) data = data4;
            else if (id == 5) data = data5;
            else return new string[] { };

            if (data.Count == 0) return new string[] { };

            int j = 0;
            int k = data.Count > 500 ? 500 : data.Count;
            string[] items = new string[k];
            for (int i = data.Count - 1; i >= 0; i--)
            {
                if (j < 500)
                {
                    items[j++] = data[i];
                }
            }

            return items;
        }
    }

    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2", "value3" };
        }

        // GET api/values/5
        public IEnumerable<string> Get(int id)
        {
            if (id >= 1 && id <= 5)
            { 
                return Values.Get(id);
            }
            else
            {
                return new string[] { "unexpected" };
            }
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
            if (value == null) return;
            string[] v = value.Split("|".ToCharArray());
            if (v.Length != 2) return;

            if (v[0] == "1") Values.Add1(v[1]);
            else if (v[0] == "2") Values.Add2(v[1]);
            else if (v[0] == "3") Values.Add3(v[1]);
            else if (v[0] == "4") Values.Add4(v[1]);
            else if (v[0] == "5") Values.Add5(v[1]);
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
