﻿

<#
 
.SYNOPSIS
This is a helper Script that can make REST API calls for and pull back metadata for all production deployments in a subscription

One parameter -- subscription ID

Sample Command:

.\MetadataExtract.ps1 -subscriptionID 98f9a3cd-a241-4ad0-9057-8d8cff55ca1f -cloudServiceName mycloudservice
 
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$True)]
    [ValidateNotNullOrEmpty()]
    $subscriptionID
)

Select-AzureRmSubscription -SubscriptionId $subscriptionID
$subscription = Get-AzureRmSubscription -SubscriptionId $subscriptionID
Write-Host "Selecting the resource groups within the subscription" 

$rgs = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName.StartsWith("p") -and $_.ResourceGroupName.EndsWith("-Migrated")}

if ($subscription) {
    if($ARMTenantAccessTokensARM.count -eq 0) {
        Connect-ARM
    }
    else {        
        if ($subscription) {
            $ARMSubscriptions.Keys | % {if($_ -eq $subscription.SubscriptionName){$val = $ARMSubscriptions.Item($_);$global:tenantId = $val.tenantId}}
        }
        if($ARMTenantAccessTokensARM){
            $ARMTenantAccessTokensARM.Keys | %{if($_ -eq $global:tenantId){$Global:accessToken = $ARMTenantAccessTokensARM.Item($_)}} 
        }
        $token = ''
        $token = 'Bearer ' + $Global:accessToken
        $uri = "https://management.azure.com/subscriptions/" + $subscription.SubscriptionId + "/resourceGroups/" + $rgs[0].ResourceGroupName + "?api-version=2014-04-01"
        write-Host -ForegroundColor Yellow $uri
        $header = @{"x-ms-version" = "2015-10-01";"Authorization" = $token}
        $xml = try {Invoke-RestMethod -Uri $uri -Method Delete -Headers $header} catch {$_.exception.response}
        if($xml.StatusCode -eq 'Unauthorized') {Connect-ARM}
   }
}
else {
    write-Host -ForegroundColor Yellow "Please set a default subscription using Select-AzureRmSubscription cmdlet"
}

if ($subscription) {
    $ARMSubscriptions.Keys | % {if($_ -eq "Cloudguy's World"){$val = $ARMSubscriptions.Item($_);$global:tenantId = $val.tenantId}}
}
else {
    write-Host -ForegroundColor Yellow "Please set a default subscription using Select-AzureSubscription cmdlet"
}

if($ARMTenantAccessTokensARM){
    $ARMTenantAccessTokensARM.Keys | %{if($_ -eq $global:tenantId){$Global:accessToken = $ARMTenantAccessTokensARM.Item($_)}} 
}
else {
    write-Host -ForegroundColor Yellow "Please Install the ARM Helper cmdlets using Install-ARMModule.ps1 and then run Conect-ARM cmdlet"
}

$token = ''
$token = 'Bearer ' + $Global:accessToken

Write-Host "Now walking through each resource group and deleting the group"

foreach ($resource in $rgs)
{
    write-host -ForegroundColor Yellow ("Attempting to delete resource group: " + $resource.ResourceGroupName)

    $uri = "https://management.azure.com/subscriptions/" + $subscription.SubscriptionId + "/resourceGroups/" + $resource.ResourceGroupName + "?api-version=2014-04-01"
    $header = @{"x-ms-version" = "2015-10-01";"Authorization" = $token}
    $xml = try {Invoke-RestMethod -Uri $uri -Method Delete -Headers $header} catch {$_.exception.response}

    if (($xml.StatusCode.value__ -eq 202) -or ($xml.StatusCode.value__ -eq 200))
    {
        write-host -ForegroundColor Green ("Status Code for DELETE Resource Group: " + $resource.ResourceGroupName + " : Status : " +  $xml.StatusCode)
    }
    else
    {
        write-host -ForegroundColor Yellow ("Status Code for DELETE Resource Group: " + $resource.ResourceGroupName + " : Status : " +  $xml.StatusCode)
    }
}

Write-Host "Completed" -ForegroundColor Green


